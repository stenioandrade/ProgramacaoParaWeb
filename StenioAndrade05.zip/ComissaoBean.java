package web;

public class ComissaoBean {
    
    private String nomeVendedor;
    private double valorVendas;
    private double comissao;
    
    public String getNomeVendedor() {
        return nomeVendedor;
    }
    
    public void setNomeVendedor(String nomeVendedor) {
        this.nomeVendedor = nomeVendedor;
    }

    public double getValorVendas() {
        return valorVendas;
    }

    public void setValorVendas(double valorVendas) {
        this.valorVendas = valorVendas;
    }

    public double getComissao() {
        calculaComissao();
        return comissao;
    }

    public void setComissao(double comissao) {
        this.comissao = comissao;
    }
    
    public void calculaComissao(){
        if(3000 <= getValorVendas() && getValorVendas() <= 5000){
            this.comissao = 100;
        }
        else if (5001 <= getValorVendas() && getValorVendas() <= 12000){
            this.comissao = getValorVendas() * 0.04;
        }
        else if (12001 <= getValorVendas() && getValorVendas() <= 20000){
            this.comissao = getValorVendas() * 0.035;
        }
        else if (getValorVendas() >= 20001){
            this.comissao = getValorVendas() * 0.02;
        }
        
    }
}
