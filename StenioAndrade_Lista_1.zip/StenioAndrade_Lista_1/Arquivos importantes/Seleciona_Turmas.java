package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import static web.Solicitacao_Matricula.DATABASE_URL;
import static web.Solicitacao_Matricula.JDBC_DRIVER;

/**
 * @author Monteiro
 */

@WebServlet(name = "Seleciona_Turmas", urlPatterns = {"/Seleciona_Turmas"})
public class Seleciona_Turmas extends HttpServlet {
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";        
    static final String DATABASE_URL = "jdbc:mysql://localhost:3306/lista_1";

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter(); 
            Connection conn;
            String matricula = request.getParameter("matricula");
            
            out.println("<!DOCTYPE html>");
            out.println("<head>");
            out.println("<div id=\"picture\">\n"
                  + "<h1><img src=\"UFS.png\" alt=\"Universidade Federal De Sergipe\"></h1></div>"
            );
            out.println("<title>Servlet ServletMySql33</title>");
            out.println("<style type=\"text/css\">"
                        + "<!-- "
                        + "h1 {text-align: center}"
                        + "body {background-image: url(bg.jpg); color:black; font-size:90%}"
                        + "td   {font-size: 100%; background-color:black; color: green}"
                        + "input {background-color:green}"
                        + "//--></style>");
            out.println("</head>");
            out.println("<body>");
       
            out.println("<h1>Turmas Ofertadas</h1>");
	        try {
	            Class.forName(JDBC_DRIVER);
	            conn = DriverManager.getConnection(DATABASE_URL, "root", "0000" );
	            Statement st1 = conn.createStatement();
                    Statement st2 = conn.createStatement();
                    Statement st3 = conn.createStatement();
	            ResultSet rec1 = st1.executeQuery(
                        "SELECT * "
                        + "FROM alunos "
                        + "WHERE "
                        + "Matrícula_Aluno='"
                        + matricula
                        + "'"
                    );// Está procurando uma matricula dentro do banco de dado, caso a encontre, retorna uma tabela com uma linha.
	      
                    ResultSet rec2 = st2.executeQuery(
                        "SELECT * "
                        + "FROM turmas "
                        + "ORDER BY Codigo_Disciplina"
	            );
                    ResultSet rec3 = st3.executeQuery(
                        "SELECT * "
                        + "FROM disciplinas "
                        + "ORDER BY Codigo_Disciplina"
	            );
                      
                    if ( rec1.first()){
                        out.println("<form action=\"Solicitacao_Matricula\">");
                        out.println("<table border=1 align=center><tr>");
                        out.println("<td><b>Código disciplina</b></td><td><b>Disciplina</b></td>"
                                  + "<td><b>Turma</b></td>"
                                  + "<td><b> Horário 1</b></td>"
                                  + "<td><b>Horário 2</b></td>"
                                  + "<td><b>Horário 3</b></td>"
                                  + "<td><b>Local</b></td>" 
                                  + "<td><b>Selecionar</b></td>" 
                                  + "</tr>"
                        );

                        int i = 0;
                        while(rec2.next() && rec3.next()) {
                            out.println("<tr><td><input type=\"hidden\" name=\"Codigo_Disciplina\" value=\""
                                    + rec2.getString(1) + "\" readonly=\"true\" />"+ rec2.getString(1)+"<br /></td>"
                                    + "<td><input type=\"hidden\" name=\"Nome_Disciplina\" value=\""
                                    + rec3.getString(2) + "\" readonly=\"true\" />"+rec3.getString(2)+"<br /></td>"
                                    + "<td><input type=\"hidden\" name=\"Turma\" value=\""
                                    + rec2.getString(2) + "\" readonly=\"true\"/>"+rec2.getString(2)+"<br /></td>"
                                    + "<td><input type=\"hidden\" name=\"horario_1\" value=\""
                                    + horario(rec2.getString(3)) + "\" />"+horario(rec2.getString(3))+"<br /></td>" 
                                    + "<td><input type=\"hidden\" name=\"horario_2\" value=\""
                                    + horario(rec2.getString(4)) + "\"/>"+horario(rec2.getString(4))+"<br /></td>" 
                                    + "<td><input type=\"hidden\" name=\"horario_3\" value=\""
                                    + horario(rec2.getString(5)) + "\" />"+horario(rec2.getString(5))+"<br /></td>"                                 
                                    + "<td><input type=\"hidden\" name=\"local\" value=\""
                                    + local(rec2.getString(6)) + "\" />"+local(rec2.getString(6))+"<br /></td>"
                                    + "<td><input type=\"checkbox\" name=\"box[" 
                                    + i + "]\" value=" + i + "/></td></tr>"); 
                            i++;
                        }
                        String num = Integer.toString(i);
                        out.println("</table>");
                        out.println("<input type='hidden' name='Nome_Aluno' value='"+rec1.getString(2)+"'/>");
                        out.println("<input type='hidden' name='Matricula_Aluno' value='"+rec1.getString(1)+"'/>");
                        out.println("<input type='hidden' name='Codigo_Curso' value='"+rec1.getString(3)+"'/>");
                        out.println("<input type='hidden' name='numRec' value='" + num + "' />");
                        out.println("<br/><h1><input type='submit' value='Enviar' name='enviar' /></h1>");
                        out.println("</form>");
                        st1.close();
                        st2.close();
                        st3.close();
                    }else{
                        out.println("<h3> Matrícula Inválida </h3> <br/> <a href = 'index.html'> Digitar Novamente </a>" );
                       }
	        } catch (SQLException s) {
	            out.println("SQL Error: " + s.toString() + " "
	                + s.getErrorCode() + " " + s.getSQLState());
	        } catch (Exception e) {
	            out.println("Error: " + e.toString()
	                + e.getMessage());
                }
        
        out.println("</body>");
        out.println("</html>");
    }
    public String horario (String horario){
        String day = null;
             if (horario.startsWith("2")) day = "Seg ";
        else if (horario.startsWith("3")) day = "Ter ";
        else if (horario.startsWith("4")) day = "Qua ";
        else if (horario.startsWith("5")) day = "Qui ";
        else if (horario.startsWith("6")) day = "Sex ";
        else day = "";
             
             if (horario.endsWith("134")) day = day + "13-17";
        else if (horario.endsWith("152")) day = day + "15-17";
        else if (horario.endsWith("172")) day = day + "17-19";
        else if (horario.endsWith("132")) day = day + "13-15";
        else day= "";
        
     return day ;
    }
    
    public String local (String sala){
        String local = null;
             if (sala.startsWith("1")) local = "Did 1, sala " +sala.substring(1);
        else if (sala.startsWith("2")) local = "Did 2, sala " +sala.substring(1);
        else if (sala.startsWith("3")) local = "Did 3, sala " +sala.substring(1);
        else if (sala.startsWith("4")) local = "Did 4, sala " +sala.substring(1);
        else if (sala.startsWith("5")) local = "Did 5, sala " +sala.substring(1);
        else local= "";
        
        return local;
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}