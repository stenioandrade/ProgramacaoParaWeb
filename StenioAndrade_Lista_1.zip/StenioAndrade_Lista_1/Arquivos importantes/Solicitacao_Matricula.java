package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 *
 * @author Monteiro
 */
@WebServlet(name = "Solicitacao_Matricula", urlPatterns = {"/Solicitacao_Matricula"})
public class Solicitacao_Matricula extends HttpServlet {
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";        
    static final String DATABASE_URL = "jdbc:mysql://localhost:3306/lista_1";
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        Connection conn;
        PrintWriter out = response.getWriter(); 
            String numRec = request.getParameter("numRec");
            int nRec = Integer.parseInt(numRec); 
            String matricula = request.getParameter("Matricula_Aluno");
            String nome = request.getParameter("Nome_Aluno");
            String codigo_Curso = request.getParameter("Codigo_Curso");
            String[] codigo_Disciplina = request.getParameterValues("Codigo_Disciplina");
            String[] nome_Disciplina = request.getParameterValues("Nome_Disciplina");
            String[] turma = request.getParameterValues("Turma");
            String[] horario_1 = request.getParameterValues("horario_1");
            String[] horario_2 = request.getParameterValues("horario_2");
            String[] horario_3 = request.getParameterValues("horario_3");
            String[] local = request.getParameterValues("local");
            try{
                Class.forName(JDBC_DRIVER );
                conn = DriverManager.getConnection(DATABASE_URL, 
                           "root", "0000");
                Statement st1 = conn.createStatement();

                out.println("<!DOCTYPE html>");
                out.println("<head>");
                out.println("<div id=\"picture\">\n"
                  + "<h1><img src=\"UFS.png\" alt=\"Universidade Federal De Sergipe\"></h1></div>"
                 );
                out.println("<title>Solicitação de matrícula</title>");
                out.println("<style type=\"text/css\">"
                            + "<!-- "
                            + "h1 {text-align: center}"
                            + "h3 {text-align: center}"
                            + "p {text-align: center}"
                            + "body {background-image: url(bg.jpg); color:black; font-size:90%}"
                            + "td   {font-size: 90%; background-color:black; color: green}"
                            + "input {text-align: center; background-color:grey}"
                            + "//--></style>"
                );
                out.println("</head>");
                out.println("<body>");
                out.println("<h1>Solicitação de matrícula</h1>");
                out.println("<h3> Dados do aluno </h3>");
                out.println("<p> Nome: " + nome +"</p>");
                out.println("<p> Matrícula: " + matricula +"</p>");
                out.println("<p> Código do curso :" + codigo_Curso +"</p>");
                out.println("<h3>Disiplinas selecionadas</h3>");
                out.println("<table border=1 align=center><tr>");
                out.println("<td><b>Código</b></td>" 
                            + "<td><b>Disciplina</b></td>" 
                            + "<td><b>Turma</b></td>"
                            + "<td><b>Horario 1</b></td>" 
                            + "<td><b>Horario 2</b></td>"
                            + "<td><b>Horario 3</b></td>" 
                            + "<td><b>lugar</b></td></tr>");
                int i = 0;
                while(i < nRec) {
                    String ok = request.getParameter("box[" + i + "]");
                    if (ok != null){
                        out.println("<tr><td>" + codigo_Disciplina[i] + "</td>"
                                    + "<td>" + nome_Disciplina[i] + "</td>"
                                    + "<td>" + turma[i] + "</td>"
                                    + "<td>" + horario_1[i] + "</td>" 
                                    + "<td>" + horario_2[i] + "</td>" 
                                    + "<td>" + horario_3[i] + "</td>"                                 
                                    + "<td>" + local[i] + "</td></tr>");
                        st1.executeUpdate("insert into `matriculas` "
                                    + "value ('" + matricula +"', '" + codigo_Disciplina[i]
                                    + "', '" + turma[i] + "')");
                        }
                        i++;
                    }
                } catch (SQLException s) {
                    out.println("SQL Error: " + s.toString() + " "
                        + s.getErrorCode() + " " + s.getSQLState());
                } catch (Exception e) {
                    out.println("Error: " + e.toString()
                        + e.getMessage());
                }
                out.println("</table>");
                out.println("</body>");
                out.println("</html>");	    
    }

        // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
        /**
         * Handles the HTTP <code>GET</code> method.
         *
         * @param request servlet request
         * @param response servlet response
         * @throws ServletException if a servlet-specific error occurs
         * @throws IOException if an I/O error occurs
         */
        @Override
        protected void doGet(HttpServletRequest request, HttpServletResponse response)
                throws ServletException, IOException {
            processRequest(request, response);
        }

        /**
         * Handles the HTTP <code>POST</code> method.
         *
         * @param request servlet request
         * @param response servlet response
         * @throws ServletException if a servlet-specific error occurs
         * @throws IOException if an I/O error occurs
         */
        @Override
        protected void doPost(HttpServletRequest request, HttpServletResponse response)
                throws ServletException, IOException {
            processRequest(request, response);
        }

        /**
         * Returns a short description of the servlet.
         *
         * @return a String containing servlet description
         */
        @Override
        public String getServletInfo() {
            return "Short description";
        }// </editor-fold>

}
