/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package web;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.ejb.Stateless;

/**
 *
 * @author Monteiro
 */
@WebService(serviceName = "CapitaisNordeste")
@Stateless()
public class CapitaisNordeste {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "getPop")
    public String getPop(@WebParam(name = "cidade") String cidade) {
        String populacao = "";
        if (cidade.equals("Aracaju")) populacao = "623.766";
        if (cidade.equals("Feira de Santana"))  populacao = "612.000";
        if (cidade.equals("Fortaleza"))  populacao = "2.571.896";
        if (cidade.equals("João Pessoa")) populacao = "780.738";
        if (cidade.equals("Maceió")) populacao = "1.005.319";
        if (cidade.equals("Natal"))  populacao = "862.044";
        if (cidade.equals("Olinda")) populacao = "388.821";
        if (cidade.equals("Recife")) populacao = "1.608.488";
        if (cidade.equals("Salvador"))  populacao = "2.902.927";
        if (cidade.equals("São Luís"))  populacao = "1.064.197";
        if (cidade.equals("Teresina"))  populacao = "840.600";
        else populacao = "Sem dados.";
        return populacao;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "capitaisNordeste")
    public String capitaisNordeste(@WebParam(name = "estado") String estado) {
        String capital = "";
        if (estado.equals("Sergipe")) capital = "Aracaju";
        if (estado.equals("Bahia"))  capital = "Salvador";
        if (estado.equals("Alagoas"))  capital = "Maceio";
        if (estado.equals("Pernambuco")) capital = "Recife";
        if (estado.equals("Paraiba")) capital = "Joao Pessoa";
        if (estado.equals("Ceara"))  capital = "Fortaleza";
        if (estado.equals("Rio Grande do Norte")) capital = "Natal";
        if (estado.equals("Piaui")) capital = "Terezina";
        if (estado.equals("Maranhao"))  capital = "Sao Luis";
        return capital;
    }

}
