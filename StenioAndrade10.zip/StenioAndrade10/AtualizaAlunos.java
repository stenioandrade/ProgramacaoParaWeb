/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Monteiro editado por Stenio Andrade
 */
@WebServlet(name = "AtualizaAlunos", urlPatterns = {"/AtualizaAlunos"})
public class AtualizaAlunos extends HttpServlet {
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";        
    static final String DATABASE_URL = "jdbc:mysql://localhost/alunos";

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * @throws java.sql.SQLException
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter(); 
        Connection conn;
        String numRec = request.getParameter("numRec");
        int num = Integer.parseInt(numRec); 
        String[] matricula = request.getParameterValues("matricula");
        String[] nome = request.getParameterValues("nome");
        String[] disciplina = request.getParameterValues("disciplina");
        String[] turma = request.getParameterValues("turma");
        String[] nota1x = request.getParameterValues("nota1");
        String[] nota2x = request.getParameterValues("nota2");
        String[] nota3x = request.getParameterValues("nota3");
        String[] faltasx = request.getParameterValues("faltas");
        // Um array com checkbox não funciona
        // Todos os campos de checkbox têm de ser identificados 
        String saida = "";
	try {
	      Class.forName(JDBC_DRIVER );
	      conn = DriverManager.getConnection(DATABASE_URL, 
                            "freire", "freire" );
	      Statement st = conn.createStatement();
              out.println("<h3>Comandos de atualizacao</h3><br/>");
	      int i = 0; 
              while(i < num) {
                  
                  String ok = request.getParameter("box[" + i + "]");
                  
                  if (ok != null){
                      
                    double nota1 = Double.parseDouble(nota1x[i]);
                    double nota2 = Double.parseDouble(nota2x[i]);
                    double nota3 = Double.parseDouble(nota3x[i]);
                    int faltas = Integer.parseInt(faltasx[i]);  
                    
                    if(nota1<10 && nota2<10 && nota3<10 && nota1>0 && nota2>0 && nota3>0 && faltas>0 && faltas<30){
                        String string1 = "UPDATE turmas1 Set nota1 = " + nota1 + ", " +
                                     "nota2 = " + nota2 + ", " + 
                                     "nota3 = " + nota3 + ", " +
                                     "faltas = " + faltas + " " +
                                     "WHERE (disciplina='" + disciplina[i] + "' and turma='" + 
                                     turma[i] + "' and matricula='" + matricula[i] + "')"; 
                        saida = saida + matricula[i] + " - " + nome[i] +  "<br/>";
                        out.println(string1 + "<br/>");
                        st.executeUpdate(string1); 
                    } else{
                        out.println("Erro, Aluno Invalido, corrija os valores!");
                        String string2 = "UPDATE turmas1 Set nota1 = " + nota1 + ", " +
                                     "nota2 = " + nota2 + ", " + 
                                     "nota3 = " + nota3 + ", " +
                                     "faltas = " + faltas + " " +
                                     "WHERE (disciplina='" + disciplina[i] + "' and turma='" + 
                                     turma[i] + "' and matricula='" + matricula[i] + "')"; 
                        saida = saida + matricula[i] + " - " + nome[i] +  "<br/>";
                        out.println(string2 + "<br/>");
                        st.executeUpdate(string2);
                        
                    }
               }
               i++;
            }
            st.close();
            conn.close();
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet AtualizaAluno</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Atualizando Alunos</h1>");                   
            out.println("<h2>Alunos atualizados:</h2><br/>" + saida);
            out.println("<form>");
            // Volta para a página anterior (lista dos alunos)
//            out.println("<br /><input type=\"button\" value=\"Voltar\" onClick=\"history.go(-1)\" />");
            // Volta para a página inicial (index)
            out.println("<br /><input type=\"button\" value=\"Voltar\" onClick=\"history.go(-2)\" />");
            out.println("</form>");
            out.println("</body>");
            out.println("</html>");
          }catch (SQLException s) {
	       out.println("SQL Error: " + s.toString() + " "
	         + s.getErrorCode() + " " + s.getSQLState());
	  }catch (Exception e) {
	       out.println("Error: " + e.toString()
	         + e.getMessage());
          }
        out.close();
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(AtualizaAlunos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(AtualizaAlunos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}